import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from config.settings import settings
from database.session import init_db
from bot.middlewares.middlewares import DBMiddleware, AuthMiddleware, ThrottleMiddleware
from bot.handlers import user, courses, payments, admin

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

async def main():
    await init_db()
    logger.info("✅ Database tayyor")

    bot = Bot(token=settings.BOT_TOKEN, parse_mode=ParseMode.HTML)
    dp = Dispatcher(storage=MemoryStorage())

    dp.update.middleware(DBMiddleware())
    dp.update.middleware(AuthMiddleware())
    dp.message.middleware(ThrottleMiddleware(limit=0.7))

    dp.include_router(user.router)
    dp.include_router(courses.router)
    dp.include_router(payments.router)
    dp.include_router(admin.router)

    logger.info("🤖 Angren Akademiya Bot ishga tushdi!")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
