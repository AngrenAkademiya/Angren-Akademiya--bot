from sqlalchemy import (
    Column, Integer, BigInteger, String, Boolean,
    DateTime, Float, ForeignKey, Text, Enum, Time, Date
)
from sqlalchemy.orm import relationship, DeclarativeBase
from sqlalchemy.sql import func
import enum


class Base(DeclarativeBase):
    pass


# ─── Enums ────────────────────────────────────────────────────────────────────

class UserStatus(str, enum.Enum):
    ACTIVE = "active"
    BLOCKED = "blocked"
    GRADUATED = "graduated"


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    PAID = "paid"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"


class EnrollStatus(str, enum.Enum):
    PENDING = "pending"      # Arizachi
    ACTIVE = "active"        # O'qiyapti
    FINISHED = "finished"    # Tugatdi
    DROPPED = "dropped"      # Tark etdi


class LessonType(str, enum.Enum):
    VIDEO = "video"
    DOCUMENT = "document"
    TEXT = "text"
    QUIZ = "quiz"


class WeekDay(str, enum.Enum):
    MON = "Dushanba"
    TUE = "Seshanba"
    WED = "Chorshanba"
    THU = "Payshanba"
    FRI = "Juma"
    SAT = "Shanba"
    SUN = "Yakshanba"


# ─── Models ───────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False, index=True)
    username = Column(String(64), nullable=True)
    full_name = Column(String(128), nullable=False)
    phone = Column(String(20), nullable=True)
    age = Column(Integer, nullable=True)
    language = Column(String(5), default="uz")
    status = Column(Enum(UserStatus), default=UserStatus.ACTIVE)
    is_admin = Column(Boolean, default=False)
    is_teacher = Column(Boolean, default=False)
    balance = Column(Float, default=0.0)
    referral_code = Column(String(10), unique=True, nullable=True)
    referred_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    joined_channel = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    enrollments = relationship("Enrollment", back_populates="user", foreign_keys="Enrollment.user_id")
    payments = relationship("Payment", back_populates="user")
    certificates = relationship("Certificate", back_populates="user")
    attendance = relationship("Attendance", back_populates="user")
    teacher_profile = relationship("Teacher", back_populates="user", uselist=False)


class Direction(Base):
    """Yo'nalish: Dasturlash, Ingliz tili, Matematika..."""
    __tablename__ = "directions"

    id = Column(Integer, primary_key=True)
    name = Column(String(128), nullable=False)
    description = Column(Text, nullable=True)
    icon = Column(String(10), default="📚")
    is_active = Column(Boolean, default=True)
    order = Column(Integer, default=0)

    courses = relationship("Course", back_populates="direction")


class Teacher(Base):
    __tablename__ = "teachers"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    full_name = Column(String(128), nullable=False)
    bio = Column(Text, nullable=True)
    speciality = Column(String(256), nullable=True)
    experience_years = Column(Integer, default=0)
    photo_file_id = Column(String(256), nullable=True)
    is_active = Column(Boolean, default=True)

    user = relationship("User", back_populates="teacher_profile")
    courses = relationship("Course", back_populates="teacher")
    groups = relationship("Group", back_populates="teacher")


class Course(Base):
    __tablename__ = "courses"

    id = Column(Integer, primary_key=True)
    direction_id = Column(Integer, ForeignKey("directions.id"), nullable=True)
    teacher_id = Column(Integer, ForeignKey("teachers.id"), nullable=True)
    title = Column(String(256), nullable=False)
    description = Column(Text, nullable=True)
    duration_months = Column(Integer, default=1)
    price_monthly = Column(Float, default=0.0)
    price_full = Column(Float, nullable=True)
    is_free = Column(Boolean, default=False)
    is_online = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    max_students = Column(Integer, default=20)
    thumbnail = Column(String(512), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    direction = relationship("Direction", back_populates="courses")
    teacher = relationship("Teacher", back_populates="courses")
    lessons = relationship("Lesson", back_populates="course", order_by="Lesson.order")
    groups = relationship("Group", back_populates="course")
    enrollments = relationship("Enrollment", back_populates="course")


class Group(Base):
    """Guruh: har bir kurs uchun alohida guruhlar"""
    __tablename__ = "groups"

    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    teacher_id = Column(Integer, ForeignKey("teachers.id"), nullable=True)
    name = Column(String(64), nullable=False)       # "A-guruhi", "Yangi guruh"
    weekdays = Column(String(128), nullable=True)   # "Dushanba, Chorshanba, Juma"
    start_time = Column(String(10), nullable=True)  # "09:00"
    end_time = Column(String(10), nullable=True)    # "11:00"
    start_date = Column(Date, nullable=True)
    max_students = Column(Integer, default=15)
    is_active = Column(Boolean, default=True)

    course = relationship("Course", back_populates="groups")
    teacher = relationship("Teacher", back_populates="groups")
    enrollments = relationship("Enrollment", back_populates="group")
    attendance = relationship("Attendance", back_populates="group")


class Enrollment(Base):
    """O'quvchining kursga yozilishi"""
    __tablename__ = "enrollments"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    group_id = Column(Integer, ForeignKey("groups.id"), nullable=True)
    status = Column(Enum(EnrollStatus), default=EnrollStatus.PENDING)
    paid_months = Column(Integer, default=0)
    discount_percent = Column(Integer, default=0)
    note = Column(Text, nullable=True)
    enrolled_at = Column(DateTime(timezone=True), server_default=func.now())
    approved_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", back_populates="enrollments", foreign_keys=[user_id])
    course = relationship("Course", back_populates="enrollments")
    group = relationship("Group", back_populates="enrollments")


class Lesson(Base):
    __tablename__ = "lessons"

    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    title = Column(String(256), nullable=False)
    content = Column(Text, nullable=True)
    lesson_type = Column(Enum(LessonType), default=LessonType.TEXT)
    file_id = Column(String(256), nullable=True)
    order = Column(Integer, default=0)
    is_preview = Column(Boolean, default=False)
    duration_minutes = Column(Integer, nullable=True)
    homework = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    course = relationship("Course", back_populates="lessons")


class Attendance(Base):
    """Davomat"""
    __tablename__ = "attendance"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    group_id = Column(Integer, ForeignKey("groups.id"), nullable=False)
    date = Column(Date, nullable=False)
    is_present = Column(Boolean, default=True)
    note = Column(String(256), nullable=True)

    user = relationship("User", back_populates="attendance")
    group = relationship("Group", back_populates="attendance")


class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    enrollment_id = Column(Integer, ForeignKey("enrollments.id"), nullable=True)
    amount = Column(Float, nullable=False)
    currency = Column(String(10), default="UZS")
    provider = Column(String(20), nullable=False)   # payme, click, cash, balance
    transaction_id = Column(String(128), nullable=True, unique=True)
    screenshot_file_id = Column(String(256), nullable=True)  # Chek rasmi
    status = Column(Enum(PaymentStatus), default=PaymentStatus.PENDING)
    months_paid = Column(Integer, default=1)
    note = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    confirmed_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", back_populates="payments")


class Certificate(Base):
    __tablename__ = "certificates"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    certificate_number = Column(String(32), unique=True, nullable=False)
    issued_at = Column(DateTime(timezone=True), server_default=func.now())
    file_id = Column(String(256), nullable=True)  # PDF/rasm fayl

    user = relationship("User", back_populates="certificates")


class Notification(Base):
    """Rejalashtirilgan bildirishnomalar"""
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True)
    title = Column(String(256), nullable=False)
    text = Column(Text, nullable=False)
    photo_file_id = Column(String(256), nullable=True)
    target = Column(String(32), default="all")  # all, students, pending
    send_at = Column(DateTime(timezone=True), nullable=True)
    sent_count = Column(Integer, default=0)
    is_sent = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class FAQ(Base):
    __tablename__ = "faqs"

    id = Column(Integer, primary_key=True)
    question = Column(String(512), nullable=False)
    answer = Column(Text, nullable=False)
    order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
