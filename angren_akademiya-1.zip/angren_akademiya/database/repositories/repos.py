from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func, and_
from sqlalchemy.orm import selectinload
from database.models.models import (
    User, Course, Direction, Teacher, Group, Enrollment,
    Lesson, Payment, Certificate, Attendance, Notification, FAQ,
    UserStatus, EnrollStatus, PaymentStatus
)
from typing import Optional, List
from datetime import datetime, date
import secrets, string, random


# ─── User Repository ──────────────────────────────────────────────────────────

class UserRepo:
    def __init__(self, s: AsyncSession): self.s = s

    def _ref_code(self) -> str:
        return ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))

    async def get(self, telegram_id: int) -> Optional[User]:
        r = await self.s.execute(select(User).where(User.telegram_id == telegram_id))
        return r.scalar_one_or_none()

    async def get_by_id(self, user_id: int) -> Optional[User]:
        r = await self.s.execute(select(User).where(User.id == user_id))
        return r.scalar_one_or_none()

    async def get_by_ref(self, code: str) -> Optional[User]:
        r = await self.s.execute(select(User).where(User.referral_code == code))
        return r.scalar_one_or_none()

    async def get_or_create(self, telegram_id: int, full_name: str, username: Optional[str] = None):
        user = await self.get(telegram_id)
        if user:
            user.full_name = full_name
            user.username = username
            return user, False
        user = User(
            telegram_id=telegram_id, full_name=full_name,
            username=username, referral_code=self._ref_code()
        )
        self.s.add(user)
        await self.s.flush()
        return user, True

    async def update_phone(self, telegram_id: int, phone: str):
        await self.s.execute(update(User).where(User.telegram_id == telegram_id).values(phone=phone))

    async def update_balance(self, user_id: int, amount: float):
        user = await self.get_by_id(user_id)
        if user: user.balance += amount

    async def count(self) -> int:
        r = await self.s.execute(select(func.count(User.id)))
        return r.scalar() or 0

    async def all_active(self) -> List[User]:
        r = await self.s.execute(select(User).where(User.status == UserStatus.ACTIVE))
        return list(r.scalars().all())

    async def get_referrals(self, user_id: int) -> List[User]:
        r = await self.s.execute(select(User).where(User.referred_by == user_id))
        return list(r.scalars().all())

    async def block(self, telegram_id: int):
        await self.s.execute(update(User).where(User.telegram_id == telegram_id).values(status=UserStatus.BLOCKED))

    async def count_new_today(self) -> int:
        today = date.today()
        r = await self.s.execute(
            select(func.count(User.id)).where(func.date(User.created_at) == today)
        )
        return r.scalar() or 0


# ─── Direction Repository ─────────────────────────────────────────────────────

class DirectionRepo:
    def __init__(self, s: AsyncSession): self.s = s

    async def all_active(self) -> List[Direction]:
        r = await self.s.execute(
            select(Direction).where(Direction.is_active == True).order_by(Direction.order)
        )
        return list(r.scalars().all())

    async def get(self, direction_id: int) -> Optional[Direction]:
        r = await self.s.execute(select(Direction).where(Direction.id == direction_id))
        return r.scalar_one_or_none()

    async def create(self, name: str, description: str = "", icon: str = "📚") -> Direction:
        d = Direction(name=name, description=description, icon=icon)
        self.s.add(d)
        await self.s.flush()
        return d


# ─── Teacher Repository ───────────────────────────────────────────────────────

class TeacherRepo:
    def __init__(self, s: AsyncSession): self.s = s

    async def all_active(self) -> List[Teacher]:
        r = await self.s.execute(
            select(Teacher).where(Teacher.is_active == True).options(selectinload(Teacher.user))
        )
        return list(r.scalars().all())

    async def get(self, teacher_id: int) -> Optional[Teacher]:
        r = await self.s.execute(
            select(Teacher).where(Teacher.id == teacher_id).options(selectinload(Teacher.courses))
        )
        return r.scalar_one_or_none()

    async def create(self, user_id: int, full_name: str, speciality: str, experience: int = 0) -> Teacher:
        t = Teacher(user_id=user_id, full_name=full_name, speciality=speciality, experience_years=experience)
        self.s.add(t)
        await self.s.flush()
        return t


# ─── Course Repository ────────────────────────────────────────────────────────

class CourseRepo:
    def __init__(self, s: AsyncSession): self.s = s

    async def all_active(self, direction_id: Optional[int] = None) -> List[Course]:
        q = select(Course).where(Course.is_active == True).options(
            selectinload(Course.teacher),
            selectinload(Course.direction),
        )
        if direction_id:
            q = q.where(Course.direction_id == direction_id)
        r = await self.s.execute(q)
        return list(r.scalars().all())

    async def get(self, course_id: int) -> Optional[Course]:
        r = await self.s.execute(
            select(Course).where(Course.id == course_id).options(
                selectinload(Course.teacher),
                selectinload(Course.direction),
                selectinload(Course.groups),
                selectinload(Course.lessons),
            )
        )
        return r.scalar_one_or_none()

    async def create(self, title: str, direction_id: int, price_monthly: float,
                     description: str = "", teacher_id: Optional[int] = None,
                     is_free: bool = False, duration_months: int = 3) -> Course:
        c = Course(
            title=title, direction_id=direction_id, price_monthly=price_monthly,
            description=description, teacher_id=teacher_id, is_free=is_free,
            duration_months=duration_months,
        )
        self.s.add(c)
        await self.s.flush()
        return c

    async def has_access(self, user_id: int, course_id: int) -> bool:
        r = await self.s.execute(
            select(Enrollment).where(
                and_(
                    Enrollment.user_id == user_id,
                    Enrollment.course_id == course_id,
                    Enrollment.status == EnrollStatus.ACTIVE,
                )
            )
        )
        return r.scalar_one_or_none() is not None

    async def get_lessons(self, course_id: int) -> List[Lesson]:
        r = await self.s.execute(
            select(Lesson).where(Lesson.course_id == course_id).order_by(Lesson.order)
        )
        return list(r.scalars().all())

    async def count(self) -> int:
        r = await self.s.execute(select(func.count(Course.id)).where(Course.is_active == True))
        return r.scalar() or 0


# ─── Group Repository ─────────────────────────────────────────────────────────

class GroupRepo:
    def __init__(self, s: AsyncSession): self.s = s

    async def by_course(self, course_id: int) -> List[Group]:
        r = await self.s.execute(
            select(Group).where(
                and_(Group.course_id == course_id, Group.is_active == True)
            ).options(selectinload(Group.teacher))
        )
        return list(r.scalars().all())

    async def get(self, group_id: int) -> Optional[Group]:
        r = await self.s.execute(select(Group).where(Group.id == group_id))
        return r.scalar_one_or_none()

    async def create(self, course_id: int, name: str, weekdays: str,
                     start_time: str, end_time: str, teacher_id: Optional[int] = None) -> Group:
        g = Group(
            course_id=course_id, name=name, weekdays=weekdays,
            start_time=start_time, end_time=end_time, teacher_id=teacher_id,
        )
        self.s.add(g)
        await self.s.flush()
        return g

    async def count_students(self, group_id: int) -> int:
        r = await self.s.execute(
            select(func.count(Enrollment.id)).where(
                and_(Enrollment.group_id == group_id, Enrollment.status == EnrollStatus.ACTIVE)
            )
        )
        return r.scalar() or 0


# ─── Enrollment Repository ────────────────────────────────────────────────────

class EnrollRepo:
    def __init__(self, s: AsyncSession): self.s = s

    async def create(self, user_id: int, course_id: int,
                     group_id: Optional[int] = None) -> Enrollment:
        e = Enrollment(user_id=user_id, course_id=course_id, group_id=group_id)
        self.s.add(e)
        await self.s.flush()
        return e

    async def get(self, enroll_id: int) -> Optional[Enrollment]:
        r = await self.s.execute(
            select(Enrollment).where(Enrollment.id == enroll_id).options(
                selectinload(Enrollment.user),
                selectinload(Enrollment.course),
                selectinload(Enrollment.group),
            )
        )
        return r.scalar_one_or_none()

    async def approve(self, enroll_id: int):
        await self.s.execute(
            update(Enrollment).where(Enrollment.id == enroll_id).values(
                status=EnrollStatus.ACTIVE,
                approved_at=func.now(),
            )
        )

    async def reject(self, enroll_id: int):
        await self.s.execute(
            update(Enrollment).where(Enrollment.id == enroll_id).values(
                status=EnrollStatus.DROPPED,
            )
        )

    async def pending_list(self) -> List[Enrollment]:
        r = await self.s.execute(
            select(Enrollment).where(Enrollment.status == EnrollStatus.PENDING).options(
                selectinload(Enrollment.user),
                selectinload(Enrollment.course),
            ).order_by(Enrollment.enrolled_at.desc())
        )
        return list(r.scalars().all())

    async def user_enrollments(self, user_id: int) -> List[Enrollment]:
        r = await self.s.execute(
            select(Enrollment).where(Enrollment.user_id == user_id).options(
                selectinload(Enrollment.course),
                selectinload(Enrollment.group),
            )
        )
        return list(r.scalars().all())

    async def count_active(self) -> int:
        r = await self.s.execute(
            select(func.count(Enrollment.id)).where(Enrollment.status == EnrollStatus.ACTIVE)
        )
        return r.scalar() or 0


# ─── Payment Repository ───────────────────────────────────────────────────────

class PaymentRepo:
    def __init__(self, s: AsyncSession): self.s = s

    async def create(self, user_id: int, amount: float, provider: str,
                     enrollment_id: Optional[int] = None,
                     screenshot_file_id: Optional[str] = None) -> Payment:
        p = Payment(
            user_id=user_id, amount=amount, provider=provider,
            enrollment_id=enrollment_id, screenshot_file_id=screenshot_file_id,
        )
        self.s.add(p)
        await self.s.flush()
        return p

    async def get(self, payment_id: int) -> Optional[Payment]:
        r = await self.s.execute(
            select(Payment).where(Payment.id == payment_id).options(
                selectinload(Payment.user),
            )
        )
        return r.scalar_one_or_none()

    async def confirm(self, payment_id: int):
        await self.s.execute(
            update(Payment).where(Payment.id == payment_id).values(
                status=PaymentStatus.PAID, confirmed_at=func.now()
            )
        )

    async def pending_list(self) -> List[Payment]:
        r = await self.s.execute(
            select(Payment).where(Payment.status == PaymentStatus.PENDING).options(
                selectinload(Payment.user)
            ).order_by(Payment.created_at.desc())
        )
        return list(r.scalars().all())

    async def user_history(self, user_id: int) -> List[Payment]:
        r = await self.s.execute(
            select(Payment).where(Payment.user_id == user_id).order_by(Payment.created_at.desc())
        )
        return list(r.scalars().all())

    async def total_income(self) -> float:
        r = await self.s.execute(
            select(func.sum(Payment.amount)).where(Payment.status == PaymentStatus.PAID)
        )
        return r.scalar() or 0.0


# ─── Certificate Repository ───────────────────────────────────────────────────

class CertRepo:
    def __init__(self, s: AsyncSession): self.s = s

    def _gen_number(self) -> str:
        year = datetime.now().year
        num = random.randint(10000, 99999)
        return f"AA-{year}-{num}"

    async def issue(self, user_id: int, course_id: int) -> Certificate:
        cert = Certificate(
            user_id=user_id, course_id=course_id,
            certificate_number=self._gen_number(),
        )
        self.s.add(cert)
        await self.s.flush()
        return cert

    async def user_certs(self, user_id: int) -> List[Certificate]:
        r = await self.s.execute(
            select(Certificate).where(Certificate.user_id == user_id).options(
                selectinload(Certificate.course)
            )
        )
        return list(r.scalars().all())


# ─── FAQ Repository ───────────────────────────────────────────────────────────

class FAQRepo:
    def __init__(self, s: AsyncSession): self.s = s

    async def all_active(self) -> List[FAQ]:
        r = await self.s.execute(
            select(FAQ).where(FAQ.is_active == True).order_by(FAQ.order)
        )
        return list(r.scalars().all())

    async def create(self, question: str, answer: str) -> FAQ:
        f = FAQ(question=question, answer=answer)
        self.s.add(f)
        await self.s.flush()
        return f
