from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery
from typing import Callable, Dict, Any, Awaitable
from database.session import async_session_maker
from database.repositories.repos import UserRepo
from database.models.models import UserStatus
import time


class DBMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        async with async_session_maker() as session:
            data["session"] = session
            try:
                result = await handler(event, data)
                await session.commit()
                return result
            except Exception:
                await session.rollback()
                raise


class AuthMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        session = data.get("session")
        tg_user = data.get("event_from_user")
        if not session or not tg_user or tg_user.is_bot:
            return await handler(event, data)

        repo = UserRepo(session)
        user, is_new = await repo.get_or_create(
            telegram_id=tg_user.id,
            full_name=tg_user.full_name,
            username=tg_user.username,
        )

        if user.status == UserStatus.BLOCKED:
            if isinstance(event, Message):
                await event.answer("⛔️ Siz bloklangansiz. Admin: @angren_akademiya")
            elif isinstance(event, CallbackQuery):
                await event.answer("⛔️ Bloklangan", show_alert=True)
            return None

        data["user"] = user
        data["is_new"] = is_new
        return await handler(event, data)


class ThrottleMiddleware(BaseMiddleware):
    def __init__(self, limit: float = 0.7):
        self.limit = limit
        self._cache: Dict[int, float] = {}

    async def __call__(self, handler, event, data):
        tg_user = data.get("event_from_user")
        if tg_user:
            uid = tg_user.id
            now = time.time()
            if now - self._cache.get(uid, 0) < self.limit:
                if isinstance(event, CallbackQuery):
                    await event.answer("⏳ Biroz kuting...", show_alert=False)
                return None
            self._cache[uid] = now
        return await handler(event, data)
