from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton,
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
from typing import List
from database.models.models import Direction, Course, Group, Teacher, FAQ


# ══════════════════════════════════════════════
#  REPLY KEYBOARDS
# ══════════════════════════════════════════════

def main_menu_kb(is_admin: bool = False, is_teacher: bool = False) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(
        KeyboardButton(text="📚 Yo'nalishlar"),
        KeyboardButton(text="📖 Kurslar"),
    )
    builder.row(
        KeyboardButton(text="👨‍🏫 O'qituvchilar"),
        KeyboardButton(text="🗓 Dars jadvali"),
    )
    builder.row(
        KeyboardButton(text="👤 Profilim"),
        KeyboardButton(text="🏆 Sertifikatlar"),
    )
    builder.row(
        KeyboardButton(text="❓ FAQ"),
        KeyboardButton(text="📞 Aloqa"),
    )
    if is_teacher:
        builder.row(KeyboardButton(text="👨‍🏫 Mening darslarim"))
    if is_admin:
        builder.row(KeyboardButton(text="⚙️ Admin panel"))
    return builder.as_markup(resize_keyboard=True)


def phone_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📱 Telefon raqamni ulashish", request_contact=True)]],
        resize_keyboard=True, one_time_keyboard=True,
    )


def cancel_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="❌ Bekor qilish")]],
        resize_keyboard=True,
    )


def skip_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="⏭ O'tkazib yuborish")]],
        resize_keyboard=True,
    )


# ══════════════════════════════════════════════
#  INLINE KEYBOARDS
# ══════════════════════════════════════════════

def directions_kb(directions: List[Direction]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for d in directions:
        builder.button(text=f"{d.icon} {d.name}", callback_data=f"dir:{d.id}")
    builder.adjust(2)
    return builder.as_markup()


def courses_kb(courses: List[Course], back: str = "directions") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for c in courses:
        label = f"{'🆓' if c.is_free else '💰'} {c.title}"
        if c.is_online:
            label = "🌐 " + label
        builder.button(text=label, callback_data=f"course:{c.id}")
    builder.button(text="⬅️ Orqaga", callback_data=back)
    builder.adjust(1)
    return builder.as_markup()


def course_detail_kb(course_id: int, has_access: bool, is_free: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if has_access or is_free:
        builder.button(text="📖 Darslar", callback_data=f"lessons:{course_id}")
    else:
        builder.button(text="✍️ Ro'yxatdan o'tish", callback_data=f"enroll:{course_id}")
    builder.button(text="👨‍🏫 O'qituvchi", callback_data=f"teacher_by_course:{course_id}")
    builder.button(text="🗓 Jadval", callback_data=f"schedule:{course_id}")
    builder.button(text="⬅️ Orqaga", callback_data="courses")
    builder.adjust(1)
    return builder.as_markup()


def groups_kb(groups: List[Group], course_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for g in groups:
        label = f"🕐 {g.name} | {g.weekdays} | {g.start_time}"
        builder.button(text=label, callback_data=f"group:{g.id}")
    builder.button(text="⬅️ Orqaga", callback_data=f"course:{course_id}")
    builder.adjust(1)
    return builder.as_markup()


def teachers_kb(teachers: List[Teacher]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for t in teachers:
        builder.button(text=f"👨‍🏫 {t.full_name}", callback_data=f"teacher:{t.id}")
    builder.adjust(1)
    return builder.as_markup()


def teacher_detail_kb(teacher_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📚 Kurslari", callback_data=f"teacher_courses:{teacher_id}")
    builder.button(text="⬅️ Orqaga", callback_data="teachers")
    builder.adjust(1)
    return builder.as_markup()


def payment_methods_kb(enroll_id: int, amount: float) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="💳 Payme", callback_data=f"pay:payme:{enroll_id}")
    builder.button(text="🔵 Click", callback_data=f"pay:click:{enroll_id}")
    builder.button(text="💵 Naqd (chek yuborish)", callback_data=f"pay:cash:{enroll_id}")
    builder.button(text="💰 Balansdan", callback_data=f"pay:balance:{enroll_id}")
    builder.button(text="❌ Bekor", callback_data=f"course:{enroll_id}")
    builder.adjust(2, 1, 1, 1)
    return builder.as_markup()


def admin_panel_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="👥 Foydalanuvchilar", callback_data="admin:users")
    builder.button(text="📋 Arizalar", callback_data="admin:enrollments")
    builder.button(text="💰 To'lovlar", callback_data="admin:payments")
    builder.button(text="📚 Kurslar", callback_data="admin:courses")
    builder.button(text="👨‍🏫 O'qituvchilar", callback_data="admin:teachers")
    builder.button(text="📢 Xabar yuborish", callback_data="admin:broadcast")
    builder.button(text="🏆 Sertifikat berish", callback_data="admin:certificate")
    builder.button(text="📊 Statistika", callback_data="admin:stats")
    builder.button(text="❓ FAQ boshqarish", callback_data="admin:faq")
    builder.adjust(2)
    return builder.as_markup()


def enroll_approve_kb(enroll_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Tasdiqlash", callback_data=f"enroll_ok:{enroll_id}")
    builder.button(text="❌ Rad etish", callback_data=f"enroll_no:{enroll_id}")
    builder.adjust(2)
    return builder.as_markup()


def payment_confirm_kb(payment_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Tasdiqlash", callback_data=f"pay_ok:{payment_id}")
    builder.button(text="❌ Rad etish", callback_data=f"pay_no:{payment_id}")
    builder.adjust(2)
    return builder.as_markup()


def faq_kb(faqs: List[FAQ]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for f in faqs:
        builder.button(text=f"❓ {f.question[:50]}", callback_data=f"faq:{f.id}")
    builder.adjust(1)
    return builder.as_markup()


def back_kb(cb: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="⬅️ Orqaga", callback_data=cb)
    return builder.as_markup()


def confirm_kb(yes: str, no: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Ha", callback_data=yes)
    builder.button(text="❌ Yo'q", callback_data=no)
    builder.adjust(2)
    return builder.as_markup()
