from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, LabeledPrice
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession
from database.models.models import User
from database.repositories.repos import PaymentRepo, EnrollRepo, UserRepo, CourseRepo
from bot.keyboards.keyboards import payment_methods_kb, payment_confirm_kb
from bot.states.states import PayCashSG
from config.settings import settings

router = Router()


@router.callback_query(F.data.startswith("pay:"))
async def pay_select(callback: CallbackQuery, user: User, session: AsyncSession, state: FSMContext):
    parts = callback.data.split(":")
    method, enroll_id = parts[1], int(parts[2])

    enroll_repo = EnrollRepo(session)
    enroll = await enroll_repo.get(enroll_id)
    if not enroll:
        await callback.answer("Ariza topilmadi", show_alert=True)
        return

    course = enroll.course
    amount = course.price_monthly

    if method == "cash":
        await state.update_data(enroll_id=enroll_id, amount=amount)
        await callback.message.answer(
            f"💵 <b>Naqd to'lov</b>\n\n"
            f"Summani to'lab, chek rasmini yuboring:\n"
            f"💰 To'lanadigan summa: <b>{amount:,.0f} so'm</b>\n\n"
            f"To'lov usullari:\n"
            f"• Payme: <code>{settings.CENTER_PHONE}</code>\n"
            f"• Click: <code>{settings.CENTER_PHONE}</code>\n"
            f"• Kassaga naqd",
            parse_mode="HTML",
        )
        await state.set_state(PayCashSG.screenshot)

    elif method == "balance":
        if user.balance < amount:
            await callback.answer(
                f"❌ Balans yetarli emas!\nBalans: {user.balance:,.0f} so'm\nKerak: {amount:,.0f} so'm",
                show_alert=True,
            )
            return
        user_repo = UserRepo(session)
        pay_repo = PaymentRepo(session)
        enroll_repo_inner = EnrollRepo(session)

        await user_repo.update_balance(user.id, -amount)
        payment = await pay_repo.create(
            user_id=user.id, amount=amount, provider="balance",
            enrollment_id=enroll_id,
        )
        await pay_repo.confirm(payment.id)
        await enroll_repo_inner.approve(enroll_id)

        await callback.message.edit_text(
            f"✅ <b>To'lov amalga oshirildi!</b>\n\n"
            f"📚 Kurs: {course.title}\n"
            f"💰 Summa: {amount:,.0f} so'm (balansdan)\n"
            f"🎉 Kurs ochildi!",
            parse_mode="HTML",
        )

    elif method in ("payme", "click"):
        amount_tiyin = int(amount * 100)
        await callback.message.answer_invoice(
            title=f"Angren Akademiya — {course.title}",
            description=f"1 oylik to'lov | {course.title}",
            payload=f"enroll:{enroll_id}:payme",
            currency="UZS",
            prices=[LabeledPrice(label=course.title, amount=amount_tiyin)],
        )
    await callback.answer()


@router.message(PayCashSG.screenshot, F.photo)
async def cash_screenshot(message: Message, user: User, session: AsyncSession, state: FSMContext):
    data = await state.get_data()
    enroll_id = data["enroll_id"]
    amount = data["amount"]
    await state.clear()

    file_id = message.photo[-1].file_id
    pay_repo = PaymentRepo(session)
    payment = await pay_repo.create(
        user_id=user.id, amount=amount, provider="cash",
        enrollment_id=enroll_id, screenshot_file_id=file_id,
    )

    # Notify admins
    for admin_id in settings.ADMIN_IDS:
        try:
            await message.bot.send_photo(
                chat_id=admin_id,
                photo=file_id,
                caption=(
                    f"💵 <b>To'lov cheki keldi!</b>\n\n"
                    f"👤 {user.full_name} (@{user.username or '—'})\n"
                    f"💰 Summa: {amount:,.0f} so'm\n"
                    f"🆔 To'lov #{payment.id}"
                ),
                reply_markup=payment_confirm_kb(payment.id),
                parse_mode="HTML",
            )
        except Exception:
            pass

    await message.answer(
        f"✅ <b>Chek yuborildi!</b>\n\n"
        f"Admin ko'rib chiqib, kursni ochadi.\n"
        f"To'lov raqami: <b>#{payment.id}</b>",
        parse_mode="HTML",
    )


@router.pre_checkout_query()
async def pre_checkout(pre_checkout_query):
    await pre_checkout_query.answer(ok=True)


@router.message(F.successful_payment)
async def on_payment_success(message: Message, user: User, session: AsyncSession):
    payload = message.successful_payment.invoice_payload
    parts = payload.split(":")
    if parts[0] == "enroll":
        enroll_id = int(parts[1])
        pay_repo = PaymentRepo(session)
        enroll_repo = EnrollRepo(session)
        enroll = await enroll_repo.get(enroll_id)

        payment = await pay_repo.create(
            user_id=user.id,
            amount=message.successful_payment.total_amount / 100,
            provider=parts[2] if len(parts) > 2 else "telegram",
            enrollment_id=enroll_id,
            transaction_id=message.successful_payment.telegram_payment_charge_id,
        )
        await pay_repo.confirm(payment.id)
        await enroll_repo.approve(enroll_id)

        course_name = enroll.course.title if enroll and enroll.course else "Kurs"
        await message.answer(
            f"🎉 <b>To'lov muvaffaqiyatli!</b>\n\n"
            f"📚 {course_name} kursi ochildi!\n"
            f"Kurslar bo'limidan darslarni ko'ring.",
            parse_mode="HTML",
        )
