from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Filter
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession
from database.models.models import User
from database.repositories.repos import (
    UserRepo, CourseRepo, DirectionRepo, TeacherRepo,
    EnrollRepo, PaymentRepo, CertRepo, FAQRepo
)
from bot.keyboards.keyboards import (
    admin_panel_kb, enroll_approve_kb, payment_confirm_kb, confirm_kb
)
from bot.states.states import (
    AdminBroadcastSG, AdminCourseSG, AdminTeacherSG,
    AdminGroupSG, AdminFAQSG, AdminCertSG
)
from config.settings import settings
import asyncio

router = Router()


class IsAdmin(Filter):
    async def __call__(self, event, user: User) -> bool:
        return user.is_admin


router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())


@router.message(F.text == "⚙️ Admin panel")
async def admin_panel(message: Message):
    await message.answer("⚙️ <b>Admin panel</b>", reply_markup=admin_panel_kb(), parse_mode="HTML")


@router.callback_query(F.data == "admin:stats")
async def stats(callback: CallbackQuery, session: AsyncSession):
    user_repo = UserRepo(session)
    course_repo = CourseRepo(session)
    enroll_repo = EnrollRepo(session)
    pay_repo = PaymentRepo(session)

    total_users = await user_repo.count()
    new_today = await user_repo.count_new_today()
    total_courses = await course_repo.count()
    active_students = await enroll_repo.count_active()
    total_income = await pay_repo.total_income()

    text = (
        f"📊 <b>Statistika</b>\n"
        f"{'─'*28}\n"
        f"👥 Jami foydalanuvchilar: <b>{total_users}</b>\n"
        f"🆕 Bugun yangi: <b>{new_today}</b>\n"
        f"📚 Faol kurslar: <b>{total_courses}</b>\n"
        f"🎓 Faol o'quvchilar: <b>{active_students}</b>\n"
        f"💰 Jami daromad: <b>{total_income:,.0f} so'm</b>"
    )
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=admin_panel_kb())


# ─── Arizalar ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:enrollments")
async def admin_enrollments(callback: CallbackQuery, session: AsyncSession):
    repo = EnrollRepo(session)
    pending = await repo.pending_list()
    if not pending:
        await callback.answer("✅ Kutayotgan ariza yo'q", show_alert=True)
        return
    for e in pending[:10]:
        await callback.message.answer(
            f"📋 <b>Ariza #{e.id}</b>\n"
            f"👤 {e.user.full_name} | 📱 {e.user.phone}\n"
            f"📚 {e.course.title}",
            reply_markup=enroll_approve_kb(e.id),
            parse_mode="HTML",
        )
    await callback.answer()


@router.callback_query(F.data.startswith("enroll_ok:"))
async def enroll_approve(callback: CallbackQuery, session: AsyncSession):
    enroll_id = int(callback.data.split(":")[1])
    repo = EnrollRepo(session)
    enroll = await repo.get(enroll_id)
    await repo.approve(enroll_id)
    try:
        await callback.bot.send_message(
            chat_id=enroll.user.telegram_id,
            text=f"🎉 <b>Arizangiz tasdiqlandi!</b>\n\n📚 {enroll.course.title} kursi ochildi!",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await callback.message.edit_text(f"✅ Ariza #{enroll_id} tasdiqlandi!")


@router.callback_query(F.data.startswith("enroll_no:"))
async def enroll_reject(callback: CallbackQuery, session: AsyncSession):
    enroll_id = int(callback.data.split(":")[1])
    repo = EnrollRepo(session)
    enroll = await repo.get(enroll_id)
    await repo.reject(enroll_id)
    try:
        await callback.bot.send_message(
            chat_id=enroll.user.telegram_id,
            text=f"❌ <b>Arizangiz rad etildi.</b>\n\nAdmin: {settings.CENTER_PHONE}",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await callback.message.edit_text(f"❌ Ariza #{enroll_id} rad etildi.")


# ─── To'lovlar ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:payments")
async def admin_payments(callback: CallbackQuery, session: AsyncSession):
    repo = PaymentRepo(session)
    pending = await repo.pending_list()
    if not pending:
        await callback.answer("✅ Kutayotgan to'lov yo'q", show_alert=True)
        return
    for p in pending[:10]:
        text = (
            f"💰 <b>To'lov #{p.id}</b>\n"
            f"👤 {p.user.full_name}\n"
            f"💵 {p.amount:,.0f} so'm | {p.provider}"
        )
        if p.screenshot_file_id:
            await callback.message.answer_photo(
                photo=p.screenshot_file_id, caption=text,
                reply_markup=payment_confirm_kb(p.id), parse_mode="HTML",
            )
        else:
            await callback.message.answer(text, reply_markup=payment_confirm_kb(p.id), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("pay_ok:"))
async def pay_confirm(callback: CallbackQuery, session: AsyncSession):
    payment_id = int(callback.data.split(":")[1])
    repo = PaymentRepo(session)
    payment = await repo.get(payment_id)
    await repo.confirm(payment_id)
    if payment.enrollment_id:
        enroll_repo = EnrollRepo(session)
        await enroll_repo.approve(payment.enrollment_id)
    try:
        await callback.bot.send_message(
            chat_id=payment.user.telegram_id,
            text=f"✅ <b>To'lovingiz tasdiqlandi!</b>\n💰 {payment.amount:,.0f} so'm",
            parse_mode="HTML",
        )
    except Exception:
        pass
    await callback.message.edit_text(f"✅ To'lov #{payment_id} tasdiqlandi!")


@router.callback_query(F.data.startswith("pay_no:"))
async def pay_reject(callback: CallbackQuery, session: AsyncSession):
    payment_id = int(callback.data.split(":")[1])
    await callback.message.edit_text(f"❌ To'lov #{payment_id} rad etildi.")


# ─── Broadcast ────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:broadcast")
async def broadcast_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("📢 Xabar matnini yuboring:")
    await state.set_state(AdminBroadcastSG.text)
    await callback.answer()


@router.message(AdminBroadcastSG.text)
async def broadcast_text(message: Message, state: FSMContext):
    await state.update_data(text=message.html_text, photo=None)
    await message.answer(
        f"👁 Ko'rinishi:\n\n{message.text}\n\n✅ Yuborasizmi?",
        reply_markup=confirm_kb("bc:yes", "bc:no"),
    )
    await state.set_state(AdminBroadcastSG.confirm)


@router.callback_query(AdminBroadcastSG.confirm, F.data == "bc:yes")
async def broadcast_send(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    data = await state.get_data()
    await state.clear()
    repo = UserRepo(session)
    users = await repo.all_active()
    sent = failed = 0
    for u in users:
        try:
            await callback.bot.send_message(u.telegram_id, data["text"], parse_mode="HTML")
            sent += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.04)
    await callback.message.edit_text(f"✅ Yuborildi: {sent}\n❌ Xato: {failed}")


@router.callback_query(F.data == "bc:no")
async def broadcast_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("❌ Bekor qilindi.")


# ─── Sertifikat ───────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:certificate")
async def cert_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("🏆 O'quvchi Telegram ID sini yuboring:")
    await state.set_state(AdminCertSG.user_id)
    await callback.answer()


@router.message(AdminCertSG.user_id, F.text.regexp(r'^\d+$'))
async def cert_user(message: Message, state: FSMContext, session: AsyncSession):
    repo = UserRepo(session)
    user = await repo.get(int(message.text))
    if not user:
        await message.answer("❌ Foydalanuvchi topilmadi. Qayta kiriting:")
        return
    await state.update_data(user_id=user.id, user_name=user.full_name)
    await message.answer(f"✅ {user.full_name}\n\nKurs ID sini kiriting:")
    await state.set_state(AdminCertSG.course_id)


@router.message(AdminCertSG.course_id, F.text.regexp(r'^\d+$'))
async def cert_course(message: Message, state: FSMContext, session: AsyncSession):
    data = await state.get_data()
    course_repo = CourseRepo(session)
    cert_repo = CertRepo(session)
    course = await course_repo.get(int(message.text))
    if not course:
        await message.answer("❌ Kurs topilmadi. Qayta kiriting:")
        return
    cert = await cert_repo.issue(data["user_id"], course.id)
    await state.clear()
    try:
        await message.bot.send_message(
            chat_id=data["user_id"],
            text=(
                f"🏆 <b>Tabriklaymiz!</b>\n\n"
                f"Siz <b>{course.title}</b> kursini muvaffaqiyatli tamomlading!\n"
                f"📜 Sertifikat raqami: <code>{cert.certificate_number}</code>"
            ),
            parse_mode="HTML",
        )
    except Exception:
        pass
    await message.answer(
        f"✅ Sertifikat berildi!\n🔢 {cert.certificate_number}\n👤 {data['user_name']}"
    )


# ─── FAQ ──────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:faq")
async def faq_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("❓ Savol matnini yuboring:")
    await state.set_state(AdminFAQSG.question)
    await callback.answer()


@router.message(AdminFAQSG.question)
async def faq_question(message: Message, state: FSMContext):
    await state.update_data(question=message.text)
    await message.answer("💬 Javob matnini yuboring:")
    await state.set_state(AdminFAQSG.answer)


@router.message(AdminFAQSG.answer)
async def faq_answer_save(message: Message, state: FSMContext, session: AsyncSession):
    data = await state.get_data()
    repo = FAQRepo(session)
    await repo.create(data["question"], message.text)
    await state.clear()
    await message.answer("✅ FAQ qo'shildi!")
