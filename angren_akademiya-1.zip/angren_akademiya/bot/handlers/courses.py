from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession
from database.models.models import User
from database.repositories.repos import (
    DirectionRepo, CourseRepo, GroupRepo, TeacherRepo, EnrollRepo
)
from bot.keyboards.keyboards import (
    directions_kb, courses_kb, course_detail_kb, groups_kb,
    teachers_kb, teacher_detail_kb, back_kb, confirm_kb
)
from bot.states.states import EnrollSG

router = Router()


# ─── Yo'nalishlar ─────────────────────────────────────────────────────────────

@router.message(F.text == "📚 Yo'nalishlar")
async def directions(message: Message, session: AsyncSession):
    repo = DirectionRepo(session)
    dirs = await repo.all_active()
    if not dirs:
        await message.answer("📭 Hozircha yo'nalishlar mavjud emas.")
        return
    await message.answer(
        "📚 <b>Yo'nalishlar</b>\n\nQiziqtirgan yo'nalishni tanlang:",
        reply_markup=directions_kb(dirs),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("dir:"))
async def direction_courses(callback: CallbackQuery, session: AsyncSession):
    dir_id = int(callback.data.split(":")[1])
    dir_repo = DirectionRepo(session)
    course_repo = CourseRepo(session)
    direction = await dir_repo.get(dir_id)
    courses = await course_repo.all_active(direction_id=dir_id)

    if not courses:
        await callback.answer("Bu yo'nalishda hozircha kurs yo'q", show_alert=True)
        return

    await callback.message.edit_text(
        f"{direction.icon} <b>{direction.name}</b>\n\nKurslardan birini tanlang:",
        reply_markup=courses_kb(courses, back="directions"),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "directions")
async def back_to_directions(callback: CallbackQuery, session: AsyncSession):
    repo = DirectionRepo(session)
    dirs = await repo.all_active()
    await callback.message.edit_text(
        "📚 <b>Yo'nalishlar</b>\n\nQiziqtirgan yo'nalishni tanlang:",
        reply_markup=directions_kb(dirs),
        parse_mode="HTML",
    )


# ─── Kurslar ──────────────────────────────────────────────────────────────────

@router.message(F.text == "📖 Kurslar")
async def all_courses(message: Message, session: AsyncSession):
    repo = CourseRepo(session)
    courses = await repo.all_active()
    if not courses:
        await message.answer("📭 Hozircha kurslar mavjud emas.")
        return
    await message.answer(
        "📖 <b>Barcha kurslar</b>\n\nKursni tanlang:",
        reply_markup=courses_kb(courses, back="directions"),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "courses")
async def all_courses_cb(callback: CallbackQuery, session: AsyncSession):
    repo = CourseRepo(session)
    courses = await repo.all_active()
    await callback.message.edit_text(
        "📖 <b>Barcha kurslar</b>",
        reply_markup=courses_kb(courses, back="directions"),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("course:"))
async def course_detail(callback: CallbackQuery, user: User, session: AsyncSession):
    course_id = int(callback.data.split(":")[1])
    repo = CourseRepo(session)
    course = await repo.get(course_id)
    if not course:
        await callback.answer("Kurs topilmadi", show_alert=True)
        return

    has_access = await repo.has_access(user.id, course_id)
    lessons = await repo.get_lessons(course_id)
    teacher_name = course.teacher.full_name if course.teacher else "Belgilanmagan"

    price_text = "Bepul" if course.is_free else f"{course.price_monthly:,.0f} so'm/oy"
    mode = "🌐 Online" if course.is_online else "🏢 Offline"

    text = (
        f"{'🆓' if course.is_free else '💰'} <b>{course.title}</b>\n"
        f"{'─' * 30}\n"
        f"📝 {course.description or 'Tavsif yo\'q'}\n\n"
        f"👨‍🏫 O'qituvchi: <b>{teacher_name}</b>\n"
        f"⏱ Davomiylik: <b>{course.duration_months} oy</b>\n"
        f"📚 Darslar: <b>{len(lessons)} ta</b>\n"
        f"💵 Narx: <b>{price_text}</b>\n"
        f"📍 Shakl: {mode}\n"
        f"🔑 Kirish: {'✅ Ochiq' if has_access or course.is_free else '🔒 Ro\'yxatdan o\'ting'}"
    )
    await callback.message.edit_text(
        text,
        reply_markup=course_detail_kb(course_id, has_access, course.is_free),
        parse_mode="HTML",
    )


# ─── Dars jadvali ─────────────────────────────────────────────────────────────

@router.message(F.text == "🗓 Dars jadvali")
async def schedule_main(message: Message, session: AsyncSession):
    repo = CourseRepo(session)
    courses = await repo.all_active()
    await message.answer(
        "🗓 <b>Dars jadvali</b>\n\nKursni tanlang:",
        reply_markup=courses_kb(courses, back="directions"),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("schedule:"))
async def course_schedule(callback: CallbackQuery, session: AsyncSession):
    course_id = int(callback.data.split(":")[1])
    group_repo = GroupRepo(session)
    course_repo = CourseRepo(session)

    groups = await group_repo.by_course(course_id)
    course = await course_repo.get(course_id)

    if not groups:
        await callback.answer("Bu kurs uchun hali jadval yo'q", show_alert=True)
        return

    text = f"🗓 <b>{course.title} — Guruhlar:</b>\n\n"
    for g in groups:
        count = await group_repo.count_students(g.id)
        available = g.max_students - count
        text += (
            f"📌 <b>{g.name}</b>\n"
            f"   📅 {g.weekdays}\n"
            f"   🕐 {g.start_time} – {g.end_time}\n"
            f"   👥 Bo'sh joy: {available} ta\n\n"
        )
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=back_kb(f"course:{course_id}"))


# ─── Ro'yxatdan o'tish ────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("enroll:"))
async def enroll_start(callback: CallbackQuery, user: User, session: AsyncSession, state: FSMContext):
    course_id = int(callback.data.split(":")[1])
    group_repo = GroupRepo(session)
    groups = await group_repo.by_course(course_id)

    if not groups:
        await callback.answer("Hozircha guruh yo'q, adminni kuting", show_alert=True)
        return

    await state.update_data(course_id=course_id)
    await callback.message.edit_text(
        "🗓 <b>Guruhni tanlang:</b>",
        reply_markup=groups_kb(groups, course_id),
        parse_mode="HTML",
    )
    await state.set_state(EnrollSG.select_group)


@router.callback_query(EnrollSG.select_group, F.data.startswith("group:"))
async def enroll_group(callback: CallbackQuery, user: User, session: AsyncSession, state: FSMContext):
    group_id = int(callback.data.split(":")[1])
    data = await state.get_data()
    course_id = data["course_id"]

    group_repo = GroupRepo(session)
    course_repo = CourseRepo(session)
    enroll_repo = EnrollRepo(session)

    group = await group_repo.get(group_id)
    course = await course_repo.get(course_id)

    # Check capacity
    count = await group_repo.count_students(group_id)
    if count >= (group.max_students or 20):
        await callback.answer("Bu guruh to'liq! Boshqasini tanlang.", show_alert=True)
        return

    await state.update_data(group_id=group_id)

    await callback.message.edit_text(
        f"✍️ <b>Ariza tasdiqlash</b>\n"
        f"{'─' * 28}\n"
        f"📚 Kurs: <b>{course.title}</b>\n"
        f"📌 Guruh: <b>{group.name}</b>\n"
        f"📅 {group.weekdays} | 🕐 {group.start_time}–{group.end_time}\n"
        f"💰 Narx: <b>{course.price_monthly:,.0f} so'm/oy</b>\n\n"
        f"Arizani yuborasizmi?",
        reply_markup=confirm_kb(f"enroll_confirm:{course_id}:{group_id}", f"course:{course_id}"),
        parse_mode="HTML",
    )
    await state.set_state(EnrollSG.confirm)


@router.callback_query(EnrollSG.confirm, F.data.startswith("enroll_confirm:"))
async def enroll_confirm(callback: CallbackQuery, user: User, session: AsyncSession, state: FSMContext):
    parts = callback.data.split(":")
    course_id, group_id = int(parts[1]), int(parts[2])

    enroll_repo = EnrollRepo(session)
    enrollment = await enroll_repo.create(user.id, course_id, group_id)
    await state.clear()

    # Notify admins
    from config.settings import settings
    for admin_id in settings.ADMIN_IDS:
        try:
            from bot.keyboards.keyboards import enroll_approve_kb
            await callback.bot.send_message(
                chat_id=admin_id,
                text=(
                    f"📋 <b>Yangi ariza!</b>\n\n"
                    f"👤 {user.full_name} (@{user.username or '—'})\n"
                    f"📱 {user.phone}\n"
                    f"🆔 Ariza #{enrollment.id}"
                ),
                reply_markup=enroll_approve_kb(enrollment.id),
                parse_mode="HTML",
            )
        except Exception:
            pass

    await callback.message.edit_text(
        f"✅ <b>Arizangiz qabul qilindi!</b>\n\n"
        f"Admin ko'rib chiqib, tez orada siz bilan bog'lanadi.\n"
        f"📋 Ariza raqami: <b>#{enrollment.id}</b>",
        parse_mode="HTML",
    )


# ─── O'qituvchilar ────────────────────────────────────────────────────────────

@router.message(F.text == "👨‍🏫 O'qituvchilar")
async def teachers_list(message: Message, session: AsyncSession):
    repo = TeacherRepo(session)
    teachers = await repo.all_active()
    if not teachers:
        await message.answer("👨‍🏫 Hozircha o'qituvchilar ro'yxati yo'q.")
        return
    await message.answer(
        "👨‍🏫 <b>O'qituvchilarimiz:</b>",
        reply_markup=teachers_kb(teachers),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "teachers")
async def teachers_cb(callback: CallbackQuery, session: AsyncSession):
    repo = TeacherRepo(session)
    teachers = await repo.all_active()
    await callback.message.edit_text(
        "👨‍🏫 <b>O'qituvchilarimiz:</b>",
        reply_markup=teachers_kb(teachers),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("teacher:"))
async def teacher_detail(callback: CallbackQuery, session: AsyncSession):
    teacher_id = int(callback.data.split(":")[1])
    repo = TeacherRepo(session)
    teacher = await repo.get(teacher_id)
    if not teacher:
        await callback.answer("Topilmadi", show_alert=True)
        return

    text = (
        f"👨‍🏫 <b>{teacher.full_name}</b>\n"
        f"{'─' * 28}\n"
        f"🎓 Mutaxassislik: {teacher.speciality or '—'}\n"
        f"⏱ Tajriba: {teacher.experience_years} yil\n\n"
        f"📝 {teacher.bio or 'Bio yo\'q'}"
    )
    if teacher.photo_file_id:
        await callback.message.answer_photo(
            photo=teacher.photo_file_id, caption=text,
            reply_markup=teacher_detail_kb(teacher_id),
            parse_mode="HTML",
        )
    else:
        await callback.message.edit_text(
            text, reply_markup=teacher_detail_kb(teacher_id), parse_mode="HTML"
        )


@router.callback_query(F.data.startswith("teacher_courses:"))
async def teacher_courses(callback: CallbackQuery, session: AsyncSession):
    teacher_id = int(callback.data.split(":")[1])
    course_repo = CourseRepo(session)
    courses = await course_repo.all_active()
    teacher_courses = [c for c in courses if c.teacher_id == teacher_id]
    if not teacher_courses:
        await callback.answer("Bu o'qituvchida kurs yo'q", show_alert=True)
        return
    await callback.message.edit_text(
        "📚 <b>O'qituvchi kurslari:</b>",
        reply_markup=courses_kb(teacher_courses, back=f"teacher:{teacher_id}"),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("teacher_by_course:"))
async def teacher_by_course(callback: CallbackQuery, session: AsyncSession):
    course_id = int(callback.data.split(":")[1])
    repo = CourseRepo(session)
    course = await repo.get(course_id)
    if not course or not course.teacher:
        await callback.answer("O'qituvchi belgilanmagan", show_alert=True)
        return
    teacher = course.teacher
    text = (
        f"👨‍🏫 <b>{teacher.full_name}</b>\n"
        f"🎓 {teacher.speciality or '—'} | {teacher.experience_years} yil tajriba\n\n"
        f"{teacher.bio or ''}"
    )
    await callback.message.edit_text(
        text,
        reply_markup=back_kb(f"course:{course_id}"),
        parse_mode="HTML",
    )
