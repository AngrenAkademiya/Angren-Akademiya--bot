from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession
from database.models.models import User
from database.repositories.repos import UserRepo, CertRepo, EnrollRepo
from bot.keyboards.keyboards import main_menu_kb, phone_kb, cancel_kb
from bot.states.states import RegSG
from config.settings import settings

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, user: User, is_new: bool, state: FSMContext):
    await state.clear()

    if is_new or not user.phone:
        await message.answer_photo(
            photo="https://telegra.ph/file/angren-logo.jpg",  # Logo URL
            caption=(
                f"🎓 <b>Angren Akademiyaga Xush Kelibsiz!</b>\n\n"
                f"Bu yerda siz:\n"
                f"✅ Dasturlash, til va ko'plab yo'nalishlarni o'rganasiz\n"
                f"✅ Professional o'qituvchilardan dars olasiz\n"
                f"✅ Sertifikat olasiz\n\n"
                f"Davom etish uchun telefon raqamingizni ulashing 👇"
            ),
            reply_markup=phone_kb(),
            parse_mode="HTML",
        )
        await state.set_state(RegSG.phone)
    else:
        await _welcome_back(message, user)


@router.message(RegSG.phone, F.contact)
async def reg_phone(message: Message, user: User, session: AsyncSession, state: FSMContext):
    repo = UserRepo(session)
    await repo.update_phone(user.telegram_id, message.contact.phone_number)
    await state.clear()
    await message.answer(
        f"✅ <b>Ro'yxatdan o'tdingiz!</b>\n\nXush kelibsiz, {user.full_name}!",
        reply_markup=main_menu_kb(is_admin=user.is_admin, is_teacher=user.is_teacher),
        parse_mode="HTML",
    )


async def _welcome_back(message: Message, user: User):
    await message.answer(
        f"👋 Xush kelibsiz, <b>{user.full_name}</b>!\n\n"
        f"🎓 <b>Angren Akademiya</b> — bilim markazi",
        reply_markup=main_menu_kb(is_admin=user.is_admin, is_teacher=user.is_teacher),
        parse_mode="HTML",
    )


@router.message(F.text == "👤 Profilim")
async def profile(message: Message, user: User, session: AsyncSession):
    enroll_repo = EnrollRepo(session)
    cert_repo = CertRepo(session)
    user_repo = UserRepo(session)

    enrollments = await enroll_repo.user_enrollments(user.id)
    certs = await cert_repo.user_certs(user.id)
    refs = await user_repo.get_referrals(user.id)

    active_courses = [e for e in enrollments if e.status.value == "active"]

    bot_info = await message.bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start=ref_{user.referral_code}"

    text = (
        f"👤 <b>Mening profilim</b>\n"
        f"{'─' * 28}\n"
        f"🆔 ID: <code>{user.telegram_id}</code>\n"
        f"👤 Ism: <b>{user.full_name}</b>\n"
        f"📱 Tel: {user.phone or '—'}\n"
        f"💰 Balans: <b>{user.balance:,.0f} so'm</b>\n\n"
        f"📚 Faol kurslar: <b>{len(active_courses)} ta</b>\n"
        f"🏆 Sertifikatlar: <b>{len(certs)} ta</b>\n"
        f"👥 Referrallar: <b>{len(refs)} ta</b>\n\n"
        f"🔗 Referral link:\n<code>{ref_link}</code>"
    )
    await message.answer(text, parse_mode="HTML")


@router.message(F.text == "🏆 Sertifikatlar")
async def my_certs(message: Message, user: User, session: AsyncSession):
    repo = CertRepo(session)
    certs = await repo.user_certs(user.id)

    if not certs:
        await message.answer(
            "🏆 Hali sertifikat olmagansiz.\n\n"
            "Kursni muvaffaqiyatli tugatgach sertifikat beriladi!"
        )
        return

    text = "🏆 <b>Sertifikatlarim:</b>\n\n"
    for cert in certs:
        text += (
            f"📜 <b>{cert.course.title if cert.course else 'Kurs'}</b>\n"
            f"   🔢 Raqam: <code>{cert.certificate_number}</code>\n"
            f"   📅 Sana: {cert.issued_at.strftime('%d.%m.%Y')}\n\n"
        )
    await message.answer(text, parse_mode="HTML")


@router.message(F.text == "📞 Aloqa")
async def contact(message: Message):
    await message.answer(
        f"📞 <b>Biz bilan bog'laning</b>\n"
        f"{'─' * 28}\n"
        f"🏢 {settings.CENTER_NAME}\n"
        f"📍 {settings.CENTER_ADDRESS}\n"
        f"📱 {settings.CENTER_PHONE}\n"
        f"📸 Instagram: {settings.CENTER_INSTAGRAM}\n\n"
        f"🕐 Ish vaqti: 9:00 – 20:00\n"
        f"📅 Dushanba – Shanba",
        parse_mode="HTML",
    )


@router.message(F.text == "❓ FAQ")
async def faq_list(message: Message, session: AsyncSession):
    from database.repositories.repos import FAQRepo
    from bot.keyboards.keyboards import faq_kb
    repo = FAQRepo(session)
    faqs = await repo.all_active()
    if not faqs:
        await message.answer("❓ Hozircha savollar yo'q.")
        return
    await message.answer(
        "❓ <b>Ko'p so'raladigan savollar:</b>\n\nSavolni tanlang:",
        reply_markup=faq_kb(faqs),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("faq:"))
async def faq_answer(callback: CallbackQuery, session: AsyncSession):
    from database.repositories.repos import FAQRepo
    from database.models.models import FAQ
    from sqlalchemy import select
    faq_id = int(callback.data.split(":")[1])
    r = await session.execute(select(FAQ).where(FAQ.id == faq_id))
    faq = r.scalar_one_or_none()
    if not faq:
        await callback.answer("Topilmadi", show_alert=True)
        return
    await callback.message.answer(
        f"❓ <b>{faq.question}</b>\n\n💬 {faq.answer}",
        parse_mode="HTML",
    )
    await callback.answer()
