from aiogram.fsm.state import State, StatesGroup


class RegSG(StatesGroup):
    phone = State()
    age = State()


class EnrollSG(StatesGroup):
    select_group = State()
    confirm = State()


class PayCashSG(StatesGroup):
    screenshot = State()


class AdminBroadcastSG(StatesGroup):
    text = State()
    photo = State()
    confirm = State()


class AdminCourseSG(StatesGroup):
    direction = State()
    title = State()
    description = State()
    price = State()
    duration = State()
    confirm = State()


class AdminGroupSG(StatesGroup):
    course = State()
    name = State()
    weekdays = State()
    time = State()
    confirm = State()


class AdminTeacherSG(StatesGroup):
    full_name = State()
    speciality = State()
    experience = State()
    bio = State()
    confirm = State()


class AdminFAQSG(StatesGroup):
    question = State()
    answer = State()


class AdminCertSG(StatesGroup):
    user_id = State()
    course_id = State()
    confirm = State()


class TopUpSG(StatesGroup):
    amount = State()
