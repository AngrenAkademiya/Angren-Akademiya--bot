from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # ─── Bot ───────────────────────────────────────────
    BOT_TOKEN: str = "YOUR_BOT_TOKEN"
    ADMIN_IDS: List[int] = []
    CHANNEL_ID: str = ""          # Majburiy obuna kanali (masalan: @angren_akademiya)
    GROUP_ID: str = ""            # Majburiy guruh

    # ─── Database ──────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://user:password@localhost/angren_db"

    # ─── API ───────────────────────────────────────────
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    SECRET_KEY: str = "angren-akademiya-secret-2025"

    # ─── Payme ─────────────────────────────────────────
    PAYME_MERCHANT_ID: str = ""
    PAYME_KEY: str = ""
    PAYME_TEST_KEY: str = ""
    PAYME_TEST_MODE: bool = True

    # ─── Click ─────────────────────────────────────────
    CLICK_SERVICE_ID: str = ""
    CLICK_MERCHANT_ID: str = ""
    CLICK_SECRET_KEY: str = ""

    # ─── Center Info ───────────────────────────────────
    CENTER_NAME: str = "Angren Akademiya"
    CENTER_ADDRESS: str = "Angren shahri, Mustaqillik ko'chasi"
    CENTER_PHONE: str = "+998 90 000 00 00"
    CENTER_INSTAGRAM: str = "@angren_akademiya"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
